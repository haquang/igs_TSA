/*
 * Motor.cpp
 *
 *  Created on: Aug 12, 2016
 *      Author: haquang
 */

#include "motor.h"

Motor::Motor() {
	// TODO Auto-generated constructor stub
	_integral = 0.0f;
}
#if SPEED_CONTROL
Motor::Motor(comedi_t* dev, int subDevDAC,int subDevADC,int subDevDIN, int measureChannel,int controlChannel, int enableMotor, int range):DaqDevice(dev) {
	_subDevDAC = subDevDAC;
	_subDevADC = subDevADC;
	_subDevDIN = subDevDIN;
	_actSpeedChannel = measureChannel;
	_setSpeedChanel = controlChannel;
	_enableChannel = enableMotor;
	_rangeIDX = range;

	comedi_dio_config(dev,_subDevDIN,_enableChannel,COMEDI_OUTPUT);
}
#else

Motor::Motor(comedi_t* dev, int subDevDAC,int subDevADC,int subDevDIN, int measureChannel,int controlChannel, int enableMotor,int direction, int range):DaqDevice(dev) {
	_subDevDAC = subDevDAC;
	_subDevADC = subDevADC;
	_subDevDIN = subDevDIN;
	_actSpeedChannel = measureChannel;
	_setSpeedChanel = controlChannel;
	_enableChannel = enableMotor;
	_directionChannel = direction;
	_rangeIDX = range;

	comedi_dio_config(dev,_subDevDIN,_enableChannel,COMEDI_OUTPUT);
	comedi_dio_config(dev,_subDevDIN,_directionChannel,COMEDI_OUTPUT);

	setupCounter(COMEDI_COUNTER_SUB,COMEDI_COUNT_IN_0,0);
}

#endif

void Motor::setPidParameters(double Kp, double Ki, double Kd) {
	_Kp = Kp;
	_Ki = Ki;
	_Kd = Kd;
}

void Motor::setCalibrationMode(){
	_calibrating = true;
}

void Motor::resetCalibrationMode(){
	_calibrating = false;
	_actPosition = 0;
	resetCounter(COMEDI_COUNTER_SUB,COMEDI_COUNT_IN_0);

}

bool Motor::isCalibrationMode(){
	return _calibrating;
}

void Motor::run() {
	if (_calibrating)
		return;

#if SPEED_CONTROL
	// update position
	double _oldActPositionTrans = _actPositionTrans;
	updateActualPositon();
	convertRotation2Translation();
	_actSpeedTran = (_actPositionTrans - _oldActPositionTrans)/_deltaT;
	//	printf("position %4.2f - %4.2f \n",_actualPosition,_desPosition);

	// PID
#if ROTATION
	double error = _desPosition - _actPosition;
	_integral += error * _deltaT;
	_desSpeed = _Kp * error + _Ki * _integral - _Kd * _actSpeed;
#else
	double error = _desPosition - _actPositionTrans;
	_integral += error * _deltaT;
	_desSpeed = _Kp * error + _Ki * _integral - _Kd * _actSpeedTran;
#endif
	//	_desSpeed = 3000;
	if (_desSpeed > MAX_SPEED)
		_desSpeed = MAX_SPEED;
	else if (_desSpeed < -MAX_SPEED)
		_desSpeed = -MAX_SPEED;
	// convert to DAC value

	//_desSpeed = 1000;
	convertSpeed2Volt();

	// Write to DAC
	//	printf("_setSpeed %5.5f - setPos %5.5f \n",_actPositionTrans,_desPosition);
	//printf("_setSpeedVolt %5.5f \n",_setSpeedVolt);

	if (COMEDI_ERROR == writeData(_subDevDAC,_setSpeedChanel,_rangeIDX,_aref,_setSpeedVolt)){
		//	printf("Error writing to subdev %d at channel %d value %2.2f \n",_subDevDAC,_setSpeedChanel,_setSpeedVolt);
	}
#else

	// Update actual position
	updateActualPositon();
	convertRotation2Translation();

	// Calculate set current

#if ROTATION
	double error = _desPosition - _actPosition;
	_integral += error * _deltaT;
	_setCurent = _Kp * error + _Ki * _integral;   // PI Controller
#else
	double error;

	//updatePidParameters(error);
	if (NORMAL == _state){
		error = _desPosition - _actPositionTrans;
		_integral += error * _deltaT;
		_setCurent = _Kp * error + _Ki * _integral + _Kd * (error - _prv_error);  // PI Controller
	}
	else{
		error = - _actPositionTrans;
		_integral += error * _deltaT;
		_setCurent = KP_DEFAULT * error + KI_DEFAULT * _integral + KD_DEFAULT * (error - _prv_error);  // PI Controller
	}
	_prv_error = error;

#endif
	if (_setCurent > MAX_CURRENT)
		_setCurent = MAX_CURRENT;
	else if (_setCurent < -MAX_CURRENT)
		_setCurent = -MAX_CURRENT;

	//	printf("_desPosition %4.4f %4.4f  Error : %4.4f, Current: %2.4f\n",_desPosition,_actPositionTrans,error,_setCurent);
	// Specify rotation direction
	//	if (err > 0)
	//		writeDIO(_subDevDIN,_directionChannel,MOTOR_CW);
	//	else
	//		writeDIO(_subDevDIN,_directionChannel,MOTOR_CCW);


	//	_setCurent = 0.0;
	// convert to DAC & send to controller
	convertCurrent2Volt();
	//_setDACVolt = 0;
	if (COMEDI_ERROR == writeData(_subDevDAC,_setSpeedChanel,_rangeIDX,_aref,_setDACVolt)){
		//	printf("Error writing to subdev %d at channel %d value %2.2f \n",_subDevDAC,_setSpeedChanel,_setSpeedVolt);
	}

	//	_err = err;
#endif

}

Motor::~Motor() {
	// TODO Auto-generated destructor stub
}

int Motor::updateActualPositon() {
	/*
	// Read value from ADC
	if (COMEDI_ERROR == readData(_subDevADC,_actSpeedChannel,_rangeIDX,_aref)){
		return COMEDI_ERROR;
	} else {
		_actSpeedVolt = getVolAnalogInput(_actSpeedChannel);
	}
	// Convert voltage to Speed (RPM)
	convertVolt2Speed();

	// Integration of speed
	_actualPosition += _actSpeed * _posconvertfactor;

	return COMEDI_OK;
	 */
	if (COMEDI_OK == readCounter(COMEDI_COUNTER_SUB,COMEDI_COUNT_IN_0))
		_actPosition = getCounter(COMEDI_COUNT_IN_0);
	//printf("Counter: %d\n ",_actPosition);
}

void Motor::convertVolt2Speed() {
	// Voltage Range : -4 -> 4 V
	// Speed Range : -10000 -> 10000 RPM
	_actSpeed = 2500 * _actSpeedVolt ;
}

void Motor::setSamplingTime(double dT) {
	_deltaT = dT; // convert to minute for intergration
	_posconvertfactor = ENCODER_RESOLUTION*_deltaT/60;
}

void Motor::disable() {

	_setCurent = 0.0;
	// convert to DAC & send to controller
	convertCurrent2Volt();
	//_setDACVolt = 0;
	if (COMEDI_ERROR == writeData(_subDevDAC,_setSpeedChanel,_rangeIDX,_aref,_setDACVolt)){
		printf("Error writing to subdev %d at channel %d value %2.2f \n",_subDevDAC,_setSpeedChanel,_setSpeedVolt);
	}
	writeDIO(_subDevDIN,_enableChannel,false);

}

void Motor::convertSpeed2Volt() {
	// Voltage Range : -10 -> 10 V
	// Speed Range : -10000 -> 10000 RPM
	_setSpeedVolt = 0.001 * _desSpeed;
}

void Motor::convertCurrent2Volt(){
	_setDACVolt = 10 * _setCurent;
}

void Motor::setPosition(double pos) {
	_desPosition = pos;
	//	printf("SET POS : %f\n",pos);
}

void Motor::enable() {
	writeDIO(_subDevDIN,_enableChannel,true);
}

double Motor::getActualPosition() {
	return _actPositionTrans;
}

double Motor::getDesignPositon() {

	return _desPosition;
}

void Motor::reset() {
	_integral = 0.0f;
}

double Motor::getActualSpeed() {
	return _actSpeed;
}

void Motor::convertTranslation2Rotation() {
	// x = 5097 y
}

void Motor::loadScheduleGainParameters(string filename) {
	ifstream ifs(filename.c_str());
	string line;
	stringstream split;
	double val;
	if (ifs) {
		getline(ifs,line);
		while (!line.empty()){
			split.clear();
			split.str(line);
			split << line;

			split >> val;
			_SG_Kp.push_back(val);

			split >> val;
			_SG_Ki.push_back(val);

			split >> val;
			_SG_Kd.push_back(val);

			split >> val;
			_SG_range.push_back(val);

			getline(ifs,line);
		}
	}
	//	// Print

		// for (int j = 0; j < _SG_range.size();j++){
		// 	printf("Kp :%4.4f,Ki :%4.4f,Kd :%4.4f,range :%4.4f \n",_SG_Kp[j],_SG_Ki[j],_SG_Kd[j],_SG_range[j]);
		// }

}

void Motor::convertRotation2Translation() {
	// y = 0.0002 x
	_actPositionTrans = 0.0002 * _actPosition;
}

void Motor::rotateClockwise() {
	printf("rotating clockwise!");
	_desSpeed = LOW_SPEED;
	convertSpeed2Volt();
	// Write to DAC
	if (COMEDI_ERROR == writeData(_subDevDAC,_setSpeedChanel,_rangeIDX,_aref,_setSpeedVolt)){
		printf("Error writing to subdev %d at channel %d value %2.2f \n",_subDevDAC,_setSpeedChanel,_setSpeedVolt);
	}
}

void Motor::rotateCounterClockwise() {
	printf("rotating counterclockwise!");
	_desSpeed = -LOW_SPEED;
	convertSpeed2Volt();
	// Write to DAC
	if (COMEDI_ERROR == writeData(_subDevDAC,_setSpeedChanel,_rangeIDX,_aref,_setSpeedVolt)){
		printf("Error writing to subdev %d at channel %d value %2.2f \n",_subDevDAC,_setSpeedChanel,_setSpeedVolt);
	}
}

void Motor::stop() {
	printf("pause!");
	_desSpeed = 0;
	convertSpeed2Volt();
	// Write to DAC
	if (COMEDI_ERROR == writeData(_subDevDAC,_setSpeedChanel,_rangeIDX,_aref,_setSpeedVolt)){
		printf("Error writing to subdev %d at channel %d value %2.2f \n",_subDevDAC,_setSpeedChanel,_setSpeedVolt);
	}
}

void Motor::updatePidParameters(double val) {

	// find position
	int i;
	for (i = 0; i < _SG_range.size();i++){
		if (abs(val) <= _SG_range[i])
			break;
	}

	// Set PID
	if (i >= _SG_range.size())
		i = _SG_range.size() - 1;

	_Kp = _SG_Kp[i];
	_Ki = _SG_Ki[i];
	_Kd = _SG_Kd[i];

	printf("Kp :%4.4f,Ki :%4.4f,Kd :%4.4f \n",_Kp,_Ki,_Kd);
}

void Motor::getPidParameters(double& Kp, double& Ki, double& Kd) {
	Kp = _Kp;
	Ki = _Ki;
	Kd = _Kd;
}

void Motor::setState(MOTOR_STATE state) {
	_state = state;
}
