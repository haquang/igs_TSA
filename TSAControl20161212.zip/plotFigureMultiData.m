clear;
close all;

%% Load data
start = 8000;
Nsamples =16000;

run('/home/haquang/workspace/rtai/TSAControl/position_soft.m')

xs1 = data(start:Nsamples,1);
xm1 = data(start:Nsamples,2);
Fm1 = -data(start:Nsamples,3);
Fs1 = -data(start:Nsamples,4);

P = polyfit(xm1,Fm1,1);
Fm1_fit = P(1) * xm1 + P(2);


start = 3000;
Nsamples =11000;

run('/home/haquang/workspace/rtai/TSAControl/position_medium.m')

xs2 = data(start:Nsamples,1);
xm2 = data(start:Nsamples,2);
Fm2 = -data(start:Nsamples,3);
Fs2 = -data(start:Nsamples,4);

P = polyfit(xm2,Fm2,1);
Fm2_fit = P(1) * xm2 + P(2);


start = 5000;
Nsamples =13000;

run('/home/haquang/workspace/rtai/TSAControl/position_hard.m')

xs3 = data(start:Nsamples,1);
xm3 = data(start:Nsamples,2);
Fm3 = -data(start:Nsamples,3);
Fs3 = -data(start:Nsamples,4);

P = polyfit(xm3,Fm3,1);
Fm3_fit = P(1) * xm3 + P(2);


%% Plot
%{
figure(1);
subplot(3,1,1);
plot(xs1,'r');
hold on;
plot(xm1,'b');
grid on

subplot(3,1,2);
plot(xs2,'r');
hold on;
plot(xm2,'b');
grid on

subplot(3,1,3);
plot(xs3,'r');
hold on;
plot(xm3,'b');
grid on
%}

t = (0:length(Fs1)-1);

figure('Units','centimeters','Position', [0, 0, 12, 9]);
set(0, 'defaultAxesTickLabelInterpreter','latex');
set(0, 'defaultLegendInterpreter','latex');
set(0, 'DefaultAxesFontSize',12);
range_y = 6;
range_x = 8000;

subplot(3,1,1);
plot(Fs1,'-r','LineWidth',1.5,'color',nicecolor('byk'),'Color',nicecolor('Myk'));
hold on;
plot(Fm1,'LineWidth',1.5,'color',nicecolor('rr'));
ylim([0 range_y]);
xlim([0 range_x]);
set(gca,'ytick',[0 range_y]);
legend('Desired','Measure','Orientation','horizontal','Location','Best','Interpreter','latex');
title('Soft','Interpreter','latex','fontsize', 8);
grid on

subplot(3,1,2);
plot(Fs2,'-r','LineWidth',1.5,'color',nicecolor('byk'),'Color',nicecolor('Myk'));
hold on;
plot(Fm2,'LineWidth',1.5,'color',nicecolor('rr'));
ylim([0 range_y]);
xlim([0 range_x]);
set(gca,'ytick',[0 range_y]);
legend('Desired','Measure','Orientation','horizontal','Location','Best','Interpreter','latex');
title('Medium','Interpreter','latex','fontsize', 8);
grid on

subplot(3,1,3);
plot(Fs3,'-r','LineWidth',1.5,'color',nicecolor('byk'),'Color',nicecolor('Myk'));
hold on;
plot(Fm3,'LineWidth',1.5,'color',nicecolor('rr'));
ylim([0 range_y]);
xlim([0 range_x]);
set(gca,'ytick',[0 range_y]);
legend('Desired','Measure','Orientation','horizontal','Location','Best','Interpreter','latex');
title('Hard','Interpreter','latex','fontsize', 8);
grid on

% % Save figure
%set(gcf, 'PaperUnits', 'centimeters');
%set(gcf, 'PaperPosition', [0 0 12 7]); 
%print('ForcePlot','-dpng','-r1200');




figure('Units','centimeters','Position', [0, 0, 12, 9]);
set(0, 'defaultAxesTickLabelInterpreter','latex');
set(0, 'defaultLegendInterpreter','latex');
set(0, 'DefaultAxesFontSize',12);

range_y = 4;
range_x = 14000;

scatter(xm1,Fm1,0.01,'r');
hold on;
plot(xm1,Fm1_fit,'r','LineWidth',3,'Color',nicecolor('Mrrk'));
hold on;
txt = '\rightarrow Soft';
text(xm1(ceil(length(xm1)/3)),Fm1_fit(ceil(length(Fm1_fit)/2)),txt,'fontsize', 15)

scatter(xm2,Fm2,0.01,'b');
hold on;
plot(xm2,Fm2_fit,'b','LineWidth',3,'Color',nicecolor('Mbbk'));
hold on;
txt = '\rightarrow Medium';
text(xm1(ceil(length(xm2)/4)),Fm2_fit(ceil(length(Fm2_fit)/2)),txt,'fontsize', 15)

scatter(xm3,Fm3,0.01,'k');
hold on;
plot(xm3,Fm3_fit,'k','LineWidth',3,'Color',nicecolor('Mk'));
hold on;
txt = '\rightarrow Hard';
text(xm1(ceil(length(xm3)/6)),Fm3_fit(ceil(length(Fm3_fit)/2)),txt,'fontsize', 15)

ylim([0 range_y]);
xlim([0 range_x]);
set(gca,'ytick',[0 range_y]);
title('Stiffness','Interpreter','latex','fontsize', 8);
grid on

set(gcf, 'PaperUnits', 'centimeters');
set(gcf, 'PaperPosition', [0 0 12 7]); 
print('StiffnessPlot','-dpng','-r1200');

