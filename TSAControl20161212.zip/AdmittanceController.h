/*
 * FSRSensor.h
 *
 *  Created on: Aug 17, 2016
 *      Author: haquang
 */

#ifndef ADMITTANCECONTROLLER_H_
#define ADMITTANCECONTROLLER_H_


#include <cmath>
#include "defines.h"
#include "daqdevice.h"
#include <stdlib.h>
#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>


using namespace std;

class AdmittanceController : public DaqDevice {

	double _ext_force = 0.0f;	// External Force
	double _err_force;
	double _prv_err_force;
	// Virtual Mass Parameters
	double _vm_position = 0.0f;	// Position
	double _vm_velocity = 0.0f;	// Velocity
	double _vm_acceleration = 0.0f;// Acceleration
	double _deltaT = 0.0f;
	double _cmd_current = 0.0f;
	// Virtual Mass-Spring-Damper
	double _mass = 0.0f;
	double _spring = 0.0f;
	double _damper = 0.0f;

	// Perceive Stiffness
	double _stiffness;
	double _viscosity;
	double _des_force;
	double _cur_bound = 0;
	// Actual Position
	double _position = 0.0f;
	double _prv_position = 0.0f;
	double _velocity = 0.0f;
	// for Sensoray/NI card
	int _subDevADC;
	int _rangeIDX = 0;
	int _forceChannelRight;
	int _forceChannelLeft;
	int _aref = AREF_GROUND;

	vector<double> _x_vect;
	vector<double> _stiffness_vect;					// GAIN-Scheduled proportional parameter


public:
	AdmittanceController();
	AdmittanceController(comedi_t* dev,int subDevADC,int forceChannelRight,int forceChannelLeft,int range);

	void solve();

	void setMassSpringDamperModel(double m,double k,double b);
	void setPerceiveStiffness(double stiffness,double damper);
	void updatePerceiveStiffness();
	void setCurPosition(double pos);

	void setSamplingTime(double dT);
	double reset();
	void run();
	void run(float extForce);
	double getVirtualMassPosition();
	double getCmdCurrent();
	double getForce();
	double getDesignForce();
	double getCurBound();

	double getPerceivedStiffness();
	void forceControl();

	void loadStiffnessRange(string filename);

	virtual ~AdmittanceController();
private:
	void readForce();
};

#endif /* ADMITTANCECONTROLLER_H_ */
