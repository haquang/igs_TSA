/*
 * Motor.h
 *
 *  Created on: Aug 12, 2016
 *      Author: haquang
 */

#ifndef MOTOR_H_
#define MOTOR_H_

#include "defines.h"
#include "daqdevice.h"

class Motor:public DaqDevice {

	double _desSpeed = 0.0f;  		// Design Speed
	double _actSpeed = 0.0f;		// Actual Speed
	double _desPosition = 0.0f;		// Design position
	double _actualPosition = 0.0f;	// Actual positon

	double _Kp=0.0f,_Ki=0.0f,_Kd = 0.0f;	// PID parameters

	double _setSpeedVolt;
	double _actSpeedVolt = 0.0f;

	double _integral;
	double _deltaT;
	double _posconvertfactor = 0.0f;

	// for sensoray/ni card
	int _subDevADC;
	int _subDevDAC;
	int _subDevDIN;
	int _rangeIDX = 0;
	int _actSpeedChannel;
	int _setSpeedChanel;
	int _enableChannel;

	int _aref = AREF_GROUND;

public:
	Motor();
	Motor(comedi_t* dev,int subDevDAC,int subDevADC,int subDevDIN,int measureChannel,int controlChannel,int enableMotor,int range);
	void setPidParameters(double Kp,double Ki, double Kd);
	void setPosition(double pos);
	void setSamplingTime(double dT);
	void run();
	void enable();
	void reset();
	void disable();
	virtual ~Motor();

	double getActualPosition();
	double getActualSpeed();
	double getDesignPositon();
private:
	int updateActualPositon();
	void convertVolt2Speed();
	void convertSpeed2Volt();

};

#endif /* MOTOR_H_ */
