/*
 * Motor.cpp
 *
 *  Created on: Aug 12, 2016
 *      Author: haquang
 */

#include "motor.h"

Motor::Motor() {
	// TODO Auto-generated constructor stub
	_integral = 0.0f;
}

Motor::Motor(comedi_t* dev, int subDevDAC,int subDevADC,int subDevDIN, int measureChannel,int controlChannel, int enableMotor, int range):DaqDevice(dev) {
	_subDevDAC = subDevDAC;
	_subDevADC = subDevADC;
	_subDevDIN = subDevDIN;
	_actSpeedChannel = measureChannel;
	_setSpeedChanel = controlChannel;
	_enableChannel = enableMotor;
	_rangeIDX = range;

	comedi_dio_config(dev,_subDevDIN,_enableChannel,COMEDI_OUTPUT);
}

void Motor::setPidParameters(double Kp, double Ki, double Kd) {
	_Kp = Kp;
	_Ki = Ki;
	_Kd = Kd;
}

void Motor::run() {

	// update position
	updateActualPositon();

//	printf("position %4.2f - %4.2f \n",_actualPosition,_desPosition);
	// PID
	double error = _desPosition - _actualPosition;
	_integral += error * _deltaT;
	_desSpeed = _Kp * error + _Ki * _integral - _Kd * _actSpeed;

	if (_desSpeed > 2000)
		_desSpeed = 2000;
	else if (_desSpeed < -2000)
		_desSpeed = -2000;
	// convert to DAC value
	convertSpeed2Volt();

	// Write to DAC
//	printf("_setSpeedVolt %2.2f \n",_setSpeedVolt);
//	_setSpeedVolt = 0.2;
	if (COMEDI_ERROR == writeData(_subDevDAC,_setSpeedChanel,_rangeIDX,_aref,_setSpeedVolt)){
		printf("Error writing to subdev %d at channel %d value %2.2f \n",_subDevDAC,_setSpeedChanel,_setSpeedVolt);
	}



}

Motor::~Motor() {
	// TODO Auto-generated destructor stub
}

int Motor::updateActualPositon() {
	// Read value from ADC
	if (COMEDI_ERROR == readData(_subDevADC,_actSpeedChannel,_rangeIDX,_aref)){
			return COMEDI_ERROR;
		} else {
			_actSpeedVolt = getVolAnalogInput(_actSpeedChannel);
		}
	// Convert voltage to Speed (RPM)
	convertVolt2Speed();

	// Integration of speed
	_actualPosition += _actSpeed * _posconvertfactor;

	return COMEDI_OK;
}

void Motor::convertVolt2Speed() {
	// Voltage Range : -4 -> 4 V
	// Speed Range : -10000 -> 10000 RPM
	_actSpeed = 2500 * _actSpeedVolt ;
}

void Motor::setSamplingTime(double dT) {
	_deltaT = dT; // convert to minute for intergration
	_posconvertfactor = ENCODER_RESOLUTION*_deltaT/60;
}

void Motor::disable() {
	writeDIO(_subDevDIN,_enableChannel,false);
}

void Motor::convertSpeed2Volt() {
	// Voltage Range : -10 -> 10 V
	// Speed Range : -10000 -> 10000 RPM
	_setSpeedVolt = 0.001 * _desSpeed;
}

void Motor::setPosition(double pos) {
	_desPosition = pos;
}

void Motor::enable() {
	writeDIO(_subDevDIN,_enableChannel,true);
}

double Motor::getActualPosition() {
	return _actualPosition;
}

double Motor::getDesignPositon() {

	return _desPosition;
}

void Motor::reset() {
	_integral = 0.0f;
}

double Motor::getActualSpeed() {
	return _actSpeed;
}
