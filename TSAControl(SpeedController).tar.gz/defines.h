/*
 * defines.h
 *
 *  Created on: Aug 12, 2016
 *      Author: haquang
 */

#define COMEDI_DEFAULT_DEVIVE "/dev/comedi0"   // Device ID for sensoray
#define COMEDI_ERROR -1
#define COMEDI_OK 0
#define COMEDI_RANGE 0
#define COMEDI_IN_CHAN_NUM 16
#define COMEDI_OUT_CHAN_NUM 4
#define COMEDI_COUNT_CHAN_NUM 3
// Sensoray Sub-channel
#define COMEDI_AN_IN_SUB 0
#define COMEDI_AN_OUT_SUB 1
#define COMEDI_DI_SUB1 2
#define COMEDI_DI_SUB2 3
#define COMEDI_DI_SUB3 4

// Channel
#define COMEDI_DAC_OUT_0 0
#define COMEDI_DAC_OUT_1 1
#define COMEDI_DIO_OUT_1 0
#define COMEDI_DIO_OUT_2 1

#define COMEDI_ENC 1
#define COMEDI_ADC_IN_0 0
#define COMEDI_ADC_IN_1 2
#define COMEDI_ADC_IN_2 3

// Schedule
#define POSITION_CONTROL_PERIOD 1000000 // ns


// Motor Controller

#define SPEED_RANGE 1000 // rpm
#define INPUT_ADC_SPEED_RANGE 4 // 0 - 4V
#define OUTPUT_DAC_SPEED_RANGE 10 // 0 - 10V
#define ENCODER_RESOLUTION 1000


#define CW 1;		// Clockwise direction
#define CCW 0;		// Counter Clockwise Direction
