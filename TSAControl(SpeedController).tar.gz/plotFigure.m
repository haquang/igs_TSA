close all;
clear;
run('/home/haquang/workspace/rtai/TSAControl/position.m')
plot(data(:,1))
hold on
plot(data(:,2),'r')
grid on