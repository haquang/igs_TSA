theta =[-1;-2;-3;-4;-5;-6;-7;-8;-9;-10;-11;-12];
force =[-1.425;-0.5;-0.7;-0.98;-1.08;-1.1619;-1.965;-2.86;-3.341;-4.362;-4.613;-6.129] ;

P = polyfit(force,theta,2)

theta_fit = P(1) * force.^2 + P(2) * force + P(3);

figure();
scatter(force,theta);
hold on;
plot(force,theta_fit);
