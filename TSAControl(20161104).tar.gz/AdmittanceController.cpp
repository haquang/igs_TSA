/*
 * FSRSensor.cpp
 *
 *  Created on: Aug 17, 2016
 *      Author: haquang
 */

#include "AdmittanceController.h"

AdmittanceController::AdmittanceController() {
	// TODO Auto-generated constructor stub

}

AdmittanceController::AdmittanceController(comedi_t* dev, int subDevADC, int forceChannelRight,int forceChannelLeft, int range) :DaqDevice(dev){
	_subDevADC = subDevADC;
	_forceChannelRight = forceChannelRight;
	_forceChannelLeft = forceChannelLeft;
	_rangeIDX = range;
}

double AdmittanceController::getForce() {
	return _extForce;
}
void AdmittanceController::readForce(){
#if SINGLE_SENSOR
	if ((COMEDI_ERROR == readData(_subDevADC,_forceChannelRight,_rangeIDX,_aref))){
			_extForce = 0.0f;
			} else {
				_extForce = getVolAnalogInput(_forceChannelRight);
//				printf("%2.2f\n",_extForce);
			}
#else
	if ((COMEDI_ERROR == readData(_subDevADC,_forceChannelRight,_rangeIDX,_aref)) || (COMEDI_ERROR == readData(_subDevADC,_forceChannelLeft,_rangeIDX,_aref))){
		_extForce = 0.0f;
		} else {
			_extForce = getVolAnalogInput(_forceChannelRight) - getVolAnalogInput(_forceChannelLeft);
		//	printf("%2.2f\n",_extForce);
		}
#endif



}
void AdmittanceController::solve() {
	// calculate new acceleration
// if (EPSILON <= _extForce - _prvExtForce){
	_acceleration = (_extForce - _velocity * _damper - _spring * _position)/_mass;
// }
// else{
// 	_acceleration = (_extForce - _velocity * _damper - 3.0*_spring * _position)/_mass;
// }
//	printf("Acceleration: %2.2f\n",_acceleration);
	// Update velocity
	_velocity = _velocity + _deltaT * _acceleration;
//	printf("_velocity: %2.2f\n",_velocity);
	// Update position
	_position = _position + _deltaT * _velocity;
	if (_position < 0)
		_position = 0;
	else if (_position > MAX_POS)
		_position = MAX_POS;
//	printf("_position: %2.2f\n",_position);
}

void AdmittanceController::setMassSpringDamperModel(double m, double k, double b) {
	_mass = m;
	_spring = k;
	_damper = b;
}

double AdmittanceController::reset() {
	_extForce = 0.0f;
	_position = 0.0f;
	_velocity = 0.0f;
	_acceleration = 0.0f;
}

void AdmittanceController::run() {
	// update external force
	_prvExtForce = _extForce;
	readForce();

	// solve derivative equation
	solve();
}

void AdmittanceController::run(float extForce) {
	// update external force
	float f = abs(extForce);
	if (f <= EPSILON)
		f = 0;

	_prvExtForce = _extForce;

	_extForce = f;

	// solve derivative equation
	solve();
}


double AdmittanceController::getPosition() {
	return _position;
}

void AdmittanceController::setSamplingTime(double dT) {
	_deltaT = dT;
}

AdmittanceController::~AdmittanceController() {
	// TODO Auto-generated destructor stub
}

