//============================================================================
// Name        : TSAControl.cpp
// Author      : Haquang
// Version     :
// Copyright   : 
// Description : Hello World in C++, Ansi-style
//============================================================================

// General
#include <iostream>
#include <fstream>
#include <vector>
#include <math.h>
// RTAI
#include <rtai_posix.h>
#include <rtai_lxrt.h>
#include <comedilib.h>
// Boost
#include <boost/thread.hpp>
#include <boost/asio.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/bind.hpp>

// Local
#include "defines.h"
#include "motor.h"
#include "AdmittanceController.h"
#include "forcesensordh.h"

boost::asio::io_service t_cali_service;

using namespace std;

/* RTAI */

pthread_t motor_control_thread;
RT_TASK *maintask;
static RTIME period_ns = POSITION_CONTROL_PERIOD;
RTIME motor_control_period; /* requested timer period, in counts */

/* Global Variable */
vector<int>* v_time;
double deltaT = (double) POSITION_CONTROL_PERIOD / 1000000000;
double T = 100.0; //second;
double t = 0.0f;
bool stop;
int exectime;
double Kp,Ki,Kd;
Motor* motor;
int position;
RTIME exec_start, exec_end;

AdmittanceController* admController;

//double mass = 0.000001f;
//double spring = 0.0001f;
//double damper = 0.00002f;

double mass = 0.0f;
double spring = 0.0f;
double damper = 0.0f;


/* Force sensor */
ForceSensorDH* forceSensor;
float samplingfrequency = 1000.0f;



/* Data Acquisition*/
vector<double> desPos;
vector<double> actPos;
vector<double> extForce;

fstream f_data;

/* Functions*/

void *motor_control_task(void *arg)
{
	int retval;
	RT_TASK *rt_task;

	/*  make this thread LXRT soft realtime */
	rt_task = rt_task_init_schmod(nam2num("MotorControl"), 1, 0, 0, SCHED_FIFO, 0xF);
	printf("THREAD INIT:name = %lu, address = %p.\n", rt_task, "MotorControl");
	mlockall(MCL_CURRENT | MCL_FUTURE);

	// makes task hard real time (default: soft)
	// uncomment the next line when developing : develop in soft real time mode
	rt_make_hard_real_time();

	motor_control_period = nano2count(period_ns);
	/* make task periodic, starting one cycle from now */
	retval = rt_task_make_periodic(rt_task,
			rt_get_time() + motor_control_period, motor_control_period);
	if (0 != retval) {
		if (-EINVAL == retval) {
			/* task structure is already in use */
			rt_printk("periodic task: task structure is invalid\n");
		} else {
			/* unknown error */
			rt_printk("periodic task: error starting task\n");
		}
		return 0;
	}
	exectime = 0.0f;
	exec_start = rt_get_cpu_time_ns();
	while (!stop){
		t+= deltaT;

		//		cout << "Time " << t << endl;
		//	if (t >= T){
		//	stop = true;
		//		motor->disable();
		//		motor->reset();
		/* Performance measure */
		//			exec_end = rt_get_cpu_time_ns();
		//			for (vector<int>::iterator it = v_time->begin();it<v_time->end();++it){
		//				printf("Exec time: %d\n",*it);
		//			}
		//			printf("THREAD: time = %4d %4d %4d %2.4f\n", exec_start, exec_end,exec_end - exec_start,t);
		//		printf("STOP \n");
		//	}

		forceSensor->readRawValue();

//		printf("Force Z : %4.4f \n", forceSensor->getForceZ());
		// Admittance Controlelr
		admController->run(forceSensor->getForceZ());
//		printf("Force %4.2f Possition: %4.2f \n",forceSensor->getForceZ(),admController->getPosition());

		motor->setPosition(admController->getPosition());

		//		position = 6000 + 6000 * sin(2*M_PI * 0.25 *t - M_PI/2);
		//		motor->setPosition(position);
		//		position = 21000;
		//		motor->setPosition(position);


		motor->run();

		desPos.push_back(admController->getPosition());
		actPos.push_back(motor->getActualPosition());
		extForce.push_back(forceSensor->getForceZ());
		//		admController->getForce();
		//	printf("Force: %2.2f \n",fstSensor->getForce());
		//	exec_end = rt_get_cpu_time_ns();
		//	v_time->push_back(exec_end - exec_start);
		rt_task_wait_period();
		//	exec_start = exec_end;
	}



	//			if (exectime <= abs(exec_end - exec_start)) {
	//				exectime = abs(exec_end - exec_start);
	//			}
	//	exec_start = exec_end;
	//
	rt_make_soft_real_time();
	rt_task_delete(rt_task);

	//
	//	 printf("THREAD: time = %d\n", exectime);
	//	 printf("THREAD %lu ENDS\n", rt_task);

	return 0;
}


void reset(){
	stop = false;
	// reset time
	t = 0.0f;
	// reset data
	desPos.clear();
	actPos.clear();
	extForce.clear();
	// reintialize thread

	if (!(motor_control_thread = rt_thread_create(motor_control_task, NULL, 10000))){
		printf("ERROR IN CREATING THREAD\n");
		exit(1);
	}
}
/*
 * Calibration function for force sensor
 */

void calibration(const boost::system::error_code& err,boost::asio::deadline_timer* t)
{
	if (err)
		return;
	if (!forceSensor->isCalibrateRequired()){
		printf("Finished calibration\n");
	} else {
		forceSensor->readRawValue();
		forceSensor->calibrate();
		t->async_wait(boost::bind(calibration,boost::asio::placeholders::error,t));
	}
}

/*
 * Flush data to file
 */
void flushToFile(string filename){

	if (f_data.is_open())
		f_data.close();

	f_data.open(filename.c_str(),std::fstream::out);
	f_data << "data = [";
	int i = 0;

	for (int i = 0; i < desPos.size();i++){
		f_data << desPos[i] << " " << actPos[i] << " " << extForce[i] << endl;
	}

	f_data << "];";
	f_data.close();
}
void keyPress(){
	cout<<"Press <s> to stop motor."<<endl;
	cout<<"Press <r> to reset position."<<endl;
	cout<<"Press <f> flush data to file."<<endl;
	cout<<"Press <t> to toggle mode."<<endl;
	cout<<"Press <q> to exit the program."<<endl;

	cout<<"Press <l> to rotate clockwise."<<endl;
	cout<<"Press <k> to pause the motor."<<endl;
	cout<<"Press <j> to rotate counterclockwise."<<endl;


	char c;
	char lastKey;
	while (true) {
		cin >> lastKey;
		switch ( lastKey ) {
		case 's':
			cout << "Stop Motor" << endl;
			stop = true;
			motor->disable();
			reset();
			rt_thread_join(motor_control_thread);
			break;
		case 'r':
			cout << "Reset!!!!: " << endl;
			admController->reset();
			reset();
			rt_thread_join(motor_control_thread);
			break;
		case 'f':
			cout << "Flushing data to file......" << endl;
			flushToFile("position.m");
			cout << "Done saving data to file ....." <<  endl;
			//			reset();
			break;

		case 't':
			if (motor->isCalibrationMode())
				motor->resetCalibrationMode();
			else
				motor->setCalibrationMode();
			break;

		case 'q':
			cout << "Exiting..." << endl;
			stop_rt_timer();
			rt_task_delete(maintask);
			motor->disable();
			printf("MASTER %p ENDS\n", maintask);
			boost::this_thread::interruption_point();
			exit(0);
			break;

		case 'j':
			motor->rotateClockwise();
			break;
		case 'k':
			motor->stop();
			break;
		case 'l':
			motor->rotateCounterClockwise();
			break;
		default:
			break;
		}
	}

}


int main(int argc, char *argv[]) {
	cout << "Starting....." << endl;

	/*
	 * Parsing arguments
	 */
	int arg = 1;
	while(arg < argc - 1)
	{
		if (!strcmp(argv[arg], "-PID")){
			Kp = (double)atof(argv[++arg]);
			cout << "Kp: " << Kp<< endl;

			Ki = (double)atof(argv[++arg]);
			cout << "Ki: " << Ki<< endl;

			Kd = (double)atof(argv[++arg]);
			cout << "Kd: " << Kd<< endl;
			arg++;
		} else if (!strcmp(argv[arg], "-MassSpringDamper")){
			mass = (double)atof(argv[++arg]);
			cout << "mass:  " << mass<< endl;

			spring = (double)atof(argv[++arg]);
			cout << "spring:  " << spring << endl;

			damper = (double)atof(argv[++arg]);
			cout << "damper:  " << damper << endl;
		} else {
			cerr << "Unrecognized option: " << argv[arg] << endl;
			exit(1);
		}
	}
	v_time = new vector<int>;
	cout << "Sampling time " << deltaT << " sec " << endl;

	/*RTAI*/
	maintask = rt_task_init(nam2num("MAIN"), 1, 0, 0);
	/* DAQ device*/
	comedi_t *device;
	/* Connect to DAQ board*/
	device = comedi_open(COMEDI_DEFAULT_DEVIVE);
	if(device == NULL){
		printf("Error connecting DAQ board\n");
		return -1;
	} else {
		printf("Connected to DAQ board: ");
		printf(comedi_get_board_name(device));
		printf("\n");
	}

	forceSensor = new ForceSensorDH(device,COMEDI_AN_IN_SUB,FIRST_INDEX_FORCE,AREF_DIFF);

	if (COMEDI_ERROR == forceSensor->DAQcalibration()){
		printf("Error calibrating DAQ board -Force Sensor\n");
	}
	forceSensor->setSampleFrequency(samplingfrequency);

	/*Timer for calibration*/

	boost::asio::deadline_timer timer_cali(t_cali_service, boost::posix_time::milliseconds(1000));
	timer_cali.async_wait(boost::bind(calibration,boost::asio::placeholders::error, &timer_cali));
	forceSensor->calibrationRequired();
	t_cali_service.run();
	while (forceSensor->isCalibrateRequired()){}


	/* Admittance controller configuration */
	admController = new AdmittanceController(device,COMEDI_AN_IN_SUB,COMEDI_ADC_IN_1,COMEDI_ADC_IN_2,COMEDI_RANGE);
	if ((COMEDI_ERROR == admController->DAQcalibration(COMEDI_AN_IN_SUB,COMEDI_ADC_IN_1,COMEDI_RANGE)) ||
			(COMEDI_ERROR == admController->DAQcalibration(COMEDI_AN_IN_SUB,COMEDI_ADC_IN_2,COMEDI_RANGE))) 	// Analog input
	{
		printf("Error calibrating DAQ board - Analog input for FSR sensor\n");
	}
	/* Motor Configuration */
#if SPEED_CONTROL
	motor = new Motor(device,COMEDI_AN_OUT_SUB,COMEDI_AN_IN_SUB,COMEDI_DI_SUB1,COMEDI_ADC_IN_1,COMEDI_DAC_OUT_0,COMEDI_DIO_OUT_1,COMEDI_RANGE);
#else
	motor = new Motor(device,COMEDI_AN_OUT_SUB,COMEDI_AN_IN_SUB,COMEDI_DI_SUB1,COMEDI_ADC_IN_1,COMEDI_DAC_OUT_0,COMEDI_DIO_OUT_1,COMEDI_DAC_OUT_1,COMEDI_RANGE);
#endif

	motor->setupCounter(COMEDI_COUNTER_SUB,COMEDI_COUNT_IN_0,0);
	if ((COMEDI_ERROR == motor->DAQcalibration(COMEDI_AN_OUT_SUB,COMEDI_DAC_OUT_0,COMEDI_RANGE)) || // Analog output
			(COMEDI_ERROR == motor->DAQcalibration(COMEDI_AN_IN_SUB,COMEDI_ADC_IN_0,COMEDI_RANGE))	)// Analog input
	{
		printf("Error calibrating DAQ board - Analog output\n");
	}

	// Motor
	motor->setSamplingTime(deltaT);
	motor->setPidParameters(Kp,Ki,Kd);
	motor->enable();

	// Admittance Control
	admController->setSamplingTime(deltaT);
	admController->setMassSpringDamperModel(mass,spring,damper);

	// set realtime timer to run in pure periodic mode
	rt_set_periodic_mode();
	// start realtime timer and scheduler
	start_rt_timer(0);
	if (!(motor_control_thread = rt_thread_create(motor_control_task, NULL, 10000))){
		printf("ERROR IN CREATING THREAD\n");
		exit(1);
	}
	//	/* Thread for key press*/
	boost::thread key_thread(&keyPress);
	key_thread.join();

	return 0;
}
