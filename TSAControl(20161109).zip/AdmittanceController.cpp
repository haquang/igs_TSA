/*
 * FSRSensor.cpp
 *
 *  Created on: Aug 17, 2016
 *      Author: haquang
 */

#include "AdmittanceController.h"

AdmittanceController::AdmittanceController() {
	// TODO Auto-generated constructor stub

}

AdmittanceController::AdmittanceController(comedi_t* dev, int subDevADC, int forceChannelRight,int forceChannelLeft, int range) :DaqDevice(dev){
	_subDevADC = subDevADC;
	_forceChannelRight = forceChannelRight;
	_forceChannelLeft = forceChannelLeft;
	_rangeIDX = range;
}

double AdmittanceController::getForce() {
	return _ext_force;
}

void AdmittanceController::setPerceiveStiffness(double stiffness) {
	_stiffness = stiffness;
}

void AdmittanceController::setCurPosition(double pos) {
	_position = pos;
}

void AdmittanceController::forceControl() {
	_vm_position = _position + _spring * _err_force + _damper * (_prv_err_force - _err_force);

	// Saturation
	if (_vm_position < 0)
		_vm_position = 0;
	else if (_vm_position > MAX_POS)
		_vm_position = MAX_POS;
}

void AdmittanceController::readForce(){
#if SINGLE_SENSOR
	if ((COMEDI_ERROR == readData(_subDevADC,_forceChannelRight,_rangeIDX,_aref))){
		_ext_force = 0.0f;
	} else {
		_ext_force = getVolAnalogInput(_forceChannelRight);
		//				printf("%2.2f\n",_extForce);
	}
#else
	if ((COMEDI_ERROR == readData(_subDevADC,_forceChannelRight,_rangeIDX,_aref)) || (COMEDI_ERROR == readData(_subDevADC,_forceChannelLeft,_rangeIDX,_aref))){
		_extForce = 0.0f;
	} else {
		_extForce = getVolAnalogInput(_forceChannelRight) - getVolAnalogInput(_forceChannelLeft);
		//	printf("%2.2f\n",_extForce);
	}
#endif
}
void AdmittanceController::solve() {
	// calculate new acceleration
	_vm_acceleration = (_err_force -  _vm_velocity * _damper -  _spring * _vm_position)/_mass;
	// Update velocity
	_vm_velocity = _vm_velocity + _deltaT * _vm_acceleration;
	// Update position
	_vm_position = _vm_position + _deltaT * _vm_velocity;
	//
	//	printf("ACC: %4.2f\n",_vm_acceleration);
	//	printf("VEL: %4.2f\n",_vm_velocity);
	//	printf("POS: %4.6f\n",_vm_position);

	// Saturation
	if (_vm_position < 0)
		_vm_position = 0;
	else if (_vm_position > MAX_POS)
		_vm_position = MAX_POS;
}

void AdmittanceController::setMassSpringDamperModel(double m, double k, double b) {
	_mass = m;
	_spring = k;

	//	_damper = 2 * _mass *sqrt(_spring/_mass);
	_damper = b;
}

double AdmittanceController::reset() {
	_ext_force = 0.0f;
	_vm_position = 0.0f;
	_vm_velocity = 0.0f;
	_vm_acceleration = 0.0f;
}

void AdmittanceController::run() {
	// update external force
	readForce();

	// solve derivative equation
	solve();
}

void AdmittanceController::run(float extForce) {
	// update external force
	float f = abs(extForce);
	if (f <= EPSILON)
		f = 0;

	_ext_force = f;

	_prv_err_force = _err_force;

//	if (0 <= _position)
		_des_force = -_stiffness * _position;
//	else
//		_des_force = 0;


	_err_force = _des_force + _ext_force;

	//	if (abs(_ext_force) <= EPSILON)
	//		_err_force = -_stiffness * _position + _vm_velocity * 20;

	//	printf("EXT: %2.5f\n",_ext_force);

	//	printf("ERR: %2.5f\n",_err_force);


	// solve derivative equation - admittance control
	//	solve();

	// force control
	forceControl();
}

double AdmittanceController::getDesignForce(){
	return _des_force;
}

double AdmittanceController::getVirtualMassPosition() {
	return _vm_position;
}

void AdmittanceController::setSamplingTime(double dT) {
	_deltaT = dT;
}

AdmittanceController::~AdmittanceController() {
	// TODO Auto-generated destructor stub
}

