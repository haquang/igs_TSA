close all;
clear;
run('/home/haquang/workspace/rtai/TSAControl/position.m')


%figure(1);
%plot(data(:,2));

figure(1);
subplot(2,1,1)
plot(data(:,1))
hold on
plot(data(:,2),'r')
hold on
plot(-data(:,3),'k');
legend('design','actual','force');
title('Position');


subplot(2,1,2)
plot(-data(:,3),'k');
hold on;
plot(-data(:,4),'r');
legend('actual','design');
title('force tracking');
grid on

%figure(2);
%plot(data(:,2),data(:,3),'k');

%{
run('/home/haquang/workspace/rtai/TSAControl/position_medium.m')


%figure(1);
%plot(data(:,2));

figure(2);
subplot(2,1,1)
plot(data(:,1))
hold on
plot(data(:,2),'r')
hold on
plot(-data(:,3),'k');
legend('design','actual','force');


subplot(2,1,2)
plot(data(:,2),-data(:,3),'k')
legend('force');
grid on


%figure(1);
%plot(data(:,2));

run('/home/haquang/workspace/rtai/TSAControl/position_hard.m')

%figure(1);
%plot(data(:,2));

figure(3);
subplot(2,1,1)
plot(data(:,1))
hold on
plot(data(:,2),'r')
hold on
plot(-data(:,3),'k');
legend('design','actual','force');


subplot(2,1,2)
plot(data(:,2),-data(:,3),'k')
legend('force');
grid on

%}