/*
 * FSRSensor.cpp
 *
 *  Created on: Aug 17, 2016
 *      Author: haquang
 */

#include "AdmittanceController.h"

AdmittanceController::AdmittanceController() {
	// TODO Auto-generated constructor stub

}

AdmittanceController::AdmittanceController(comedi_t* dev, int subDevADC, int forceChannelRight,int forceChannelLeft, int range) :DaqDevice(dev){
	_subDevADC = subDevADC;
	_forceChannelRight = forceChannelRight;
	_forceChannelLeft = forceChannelLeft;
	_rangeIDX = range;
}

double AdmittanceController::getForce() {
	return _ext_force;
}

void AdmittanceController::setPerceiveStiffness(double stiffness,double viscosity) {
	_stiffness = stiffness;
	_viscosity = viscosity;
}

void AdmittanceController::updatePerceiveStiffness() {
	for (int i = 0; i < _x_vect.size(); ++i) {
		if (abs(_position) <= abs(_x_vect[i])){
			_stiffness = _stiffness_vect[i];
			_proxy_mass = _mass_vect[i];
			_viscosity = _damper_vect[i];
			return;
		}
	}
	return;

}
void AdmittanceController::updateProxyPosition(){
	double F, acc;
#if DRILL
	// Spring force on proxy
	double deltaPosition = abs(_position - _proxy_pos);
	F = _stiffness * (COMPRESSION_SPRING_LENGTH - deltaPosition) - _viscosity * _proxy_vel;
	// Update position
	acc = F/_proxy_mass;
	_proxy_vel += acc * _deltaT;
	_proxy_pos += _proxy_vel * _deltaT;
#else
	_proxy_pos = _proxy;
#endif
}

double AdmittanceController::getProxyPosition(){
	return _proxy_pos;
}

void AdmittanceController::setCurPosition(double pos) {
	_prv_position = _position;
	_position = pos;
	_velocity = (_position - _prv_position)/_deltaT;
}

void AdmittanceController::forceControl() {
	if (_position > MAX_POS){
		_cmd_current = 0;
		return;
	}

#if CURRENT_CONTROL
	_cmd_current = _spring * _err_force + _damper * (_prv_err_force - _err_force);
#else
	_vm_position = _spring * _err_force + _damper * (_prv_err_force - _err_force);

	// Saturation
	if (_vm_position < 0)
		_vm_position = 0;
	else if (_vm_position > MAX_POS){
		_vm_position = MAX_POS;
//	printf("pos: %6.5f\n",_vm_position);
	}
#endif




}

double AdmittanceController::getPerceivedStiffness() {
	return _stiffness;
}

double AdmittanceController::getCurBound() {
	return _proxy;
}

void AdmittanceController::setProxyMass(double mass) {
	_proxy_mass = mass;
}

void AdmittanceController::readForce(){
#if SINGLE_SENSOR
	if ((COMEDI_ERROR == readData(_subDevADC,_forceChannelRight,_rangeIDX,_aref))){
		_ext_force = 0.0f;
	} else {
		_ext_force = getVolAnalogInput(_forceChannelRight);
		//				printf("%2.2f\n",_extForce);
	}
#else
	if ((COMEDI_ERROR == readData(_subDevADC,_forceChannelRight,_rangeIDX,_aref)) || (COMEDI_ERROR == readData(_subDevADC,_forceChannelLeft,_rangeIDX,_aref))){
		_extForce = 0.0f;
	} else {
		_extForce = getVolAnalogInput(_forceChannelRight) - getVolAnalogInput(_forceChannelLeft);
		//	printf("%2.2f\n",_extForce);
	}
#endif
}
void AdmittanceController::solve() {
	// calculate new acceleration
	_vm_acceleration = (-_err_force -  _vm_velocity * _damper -  _spring * _vm_position)/_mass;
	// Update velocity
	_vm_velocity = _vm_velocity + _deltaT * _vm_acceleration;
	// Update position
	_vm_position = _vm_position + _deltaT * _vm_velocity;
	//
	//	printf("ACC: %4.2f\n",_vm_acceleration);
	//	printf("VEL: %4.2f\n",_vm_velocity);
	printf("POS: %4.6f\n",_vm_position);

	// Saturation
	//	if (_vm_position < 0)
	//		_vm_position = 0;
	//	else if (_vm_position > MAX_POS)
	//		_vm_position = MAX_POS;
}

void AdmittanceController::setMassSpringDamperModel(double m, double k, double b) {
	_mass = m;
	_spring = k;

	//	_damper = 2 * _mass *sqrt(_spring/_mass);
	_damper = b;
}

double AdmittanceController::reset() {
	_ext_force = 0.0f;
	_vm_position = 0.0f;
	_vm_velocity = 0.0f;
	_vm_acceleration = 0.0f;
}

void AdmittanceController::run() {
	// update external force
	readForce();

	// solve derivative equation
	solve();
}

void AdmittanceController::run(float extForce) {
	// update external force
	float f = abs(extForce);
	if (f <= EPSILON)
		f = 0;

	_ext_force = f ;

	_prv_err_force = _err_force;

	//	if (0 <= _position)
#if PROXY
	double deltaPosition = abs(_position - _proxy_pos);
	if (deltaPosition <= COMPRESSION_SPRING_LENGTH)
		_des_force = -_stiffness * (COMPRESSION_SPRING_LENGTH - deltaPosition) - _viscosity * _vm_velocity/_deltaT;
	else {
		_vm_position = _position;
	}
#else
	_des_force = -_stiffness * (_position-_proxy);
#endif
	//	_des_force = -_stiffness * _position;
	//	else
	//		_des_force = 0;

	//	printf("des force: %4.3f \n",_des_force);
	_err_force = _des_force + _ext_force;

	//	if (abs(_ext_force) <= EPSILON)
	//		_err_force = -_stiffness * _position + _vm_velocity * 20;

	//	printf("EXT: %2.5f\n",_ext_force);

	//	printf("ERR: %2.5f\n",_err_force);


	// solve derivative equation - admittance control
	//	solve();

	// force control
	forceControl();
	// Stiffness Control

//
//		if (abs(_position) <= 0.001 )
//			_m_stiffness = MAX_STIFFNESS;
//		else {
//			_m_stiffness = _ext_force/abs(_position);
//			if (_m_stiffness > MAX_STIFFNESS)
//				_m_stiffness = MAX_STIFFNESS;
//		}
//		stiffnessControl();
}

void AdmittanceController::stiffnessControl() {
	_prv_err_stiffness = _err_stiffness;
	_err_stiffness = _m_stiffness - _stiffness;
#if CURRENT_CONTROL
	_cmd_current = _spring * _err_stiffness + _damper * (_prv_err_stiffness - _err_stiffness);
#else
	_vm_position = _spring * _err_stiffness + _damper * (_prv_err_stiffness - _err_stiffness);
#endif
}

double AdmittanceController::getStiffness(){
	return _m_stiffness;
}


double AdmittanceController::getCmdCurrent(){
	return _cmd_current;
}

double AdmittanceController::getDesignForce(){
	return _des_force;
}

double AdmittanceController::getVirtualMassPosition() {
	return _vm_position;
}

void AdmittanceController::setSamplingTime(double dT) {
	_deltaT = dT;
}

AdmittanceController::~AdmittanceController() {
	// TODO Auto-generated destructor stub
}

void AdmittanceController::loadStiffnessRange(string filename) {
	ifstream ifs(filename.c_str());
	string line;
	stringstream split;
	double val;
	if (ifs) {
		getline(ifs,line);
		while (!line.empty()){
			split.clear();
			split.str(line);
			split << line;

			split >> val;
			_x_vect.push_back(val);

			split >> val;
			_stiffness_vect.push_back(val);

			split >> val;
			_mass_vect.push_back(val);

			split >> val;
			_damper_vect.push_back(val);

			getline(ifs,line);
		}
	}
	// Print

	for (int j = 0; j < _x_vect.size();j++){
		printf("Position :%4.4f,Stiffness :%4.4f \n",_x_vect[j],_stiffness_vect[j]);
	}

}
