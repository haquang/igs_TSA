close all;
clear;
run('/home/haquang/workspace/rtai/TSAControl/position.m')

%% Load data
start= 1;
Nsamples = length(data(:,1));


idx = find(data(:,2)>0.5,1) + 0;

idx2 = find(data(:,2)>= 1.0,1,'first') + 0;

m = max(data(:,2));
idx3 = find(data(:,2) >= m,1,'first');

x1 = 3 +data(start:idx ,2) - data(start:idx ,1);
x2 = 3 +data(idx:idx2,2) - data(idx:idx2,1);
x3 =  3 +data(idx2:idx3,2) - data(idx2:idx3,1);

F1 = -data(start:idx,4);
F2 = -data(idx:idx2,4);
F3 = -data(idx2:idx3,4);

P = polyfit(x1,F1,1);
Fm1_fit = P(1) * x1 + P(2);

P = polyfit(x2,F2,1);
Fm2_fit = P(1) * x2 + P(2);

P = polyfit(x3,F3,1);
Fm3_fit = P(1) * x3 + P(2);
%% Plot
figure('Units','centimeters','Position', [0, 0, 12, 9]);
set(0, 'defaultAxesTickLabelInterpreter','latex');
set(0, 'defaultLegendInterpreter','latex');
set(0, 'DefaultAxesFontSize',12);

scatter(x1,F1,0.1,'r');
hold on;
plot(x1,Fm1_fit,'r','LineWidth',3,'Color',nicecolor('Mrrk'));
hold on;

scatter(x2,F2,0.1,'b');
hold on;
plot(x2,Fm2_fit,'b','LineWidth',3,'Color',nicecolor('Mbbk'));
hold on;

%scatter(x3,F3,0.1,'k');
%hold on;
%plot(x3,Fm3_fit,'b','LineWidth',3,'Color',nicecolor('Myyk'));

grid on

