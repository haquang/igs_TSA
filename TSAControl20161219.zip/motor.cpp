/*
 * Motor.cpp
 *
 *  Created on: Aug 12, 2016
 *      Author: haquang
 */

#include "motor.h"

Motor::Motor() {
	// TODO Auto-generated constructor stub
	_integral = 0.0f;
}
#if SPEED_CONTROL
Motor::Motor(comedi_t* dev, int subDevDAC,int subDevADC,int subDevDIN, int measureChannel,int controlChannel, int enableMotor, int range):DaqDevice(dev) {
	_subDevDAC = subDevDAC;
	_subDevADC = subDevADC;
	_subDevDIN = subDevDIN;
	_actSpeedChannel = measureChannel;
	_setSpeedChanel = controlChannel;
	_enableChannel = enableMotor;
	_rangeIDX = range;

	comedi_dio_config(dev,_subDevDIN,_enableChannel,COMEDI_OUTPUT);
}
#else

Motor::Motor(comedi_t* dev, int subDevDAC,int subDevADC,int subDevDIN, int measureChannel,int controlChannel, int enableMotor,int direction, int range):DaqDevice(dev) {
	_subDevDAC = subDevDAC;
	_subDevADC = subDevADC;
	_subDevDIN = subDevDIN;
	_actSpeedChannel = measureChannel;
	_setSpeedChanel = controlChannel;
	_enableChannel = enableMotor;
	_directionChannel = direction;
	_rangeIDX = range;

	comedi_dio_config(dev,_subDevDIN,_enableChannel,COMEDI_OUTPUT);
	comedi_dio_config(dev,_subDevDIN,_directionChannel,COMEDI_OUTPUT);

	setupCounter(COMEDI_COUNTER_SUB,COMEDI_COUNT_IN_0,0);
}

#endif

void Motor::setPidParameters(double Kp, double Ki, double Kd) {
	_Kp = Kp;
	_Ki = Ki;
	_Kd = Kd;
}

void Motor::setCalibrationMode(){
	_calibrating = true;
}

void Motor::resetCalibrationMode(){
	_calibrating = false;
	_actPosition = 0;
	resetCounter(COMEDI_COUNTER_SUB,COMEDI_COUNT_IN_0);

}

bool Motor::isCalibrationMode(){
	return _calibrating;
}

void Motor::run() {
	if (_calibrating)
		return;

#if SPEED_CONTROL
	// update position
	double _oldActPositionTrans = _actPositionTrans;
	updateActualPositon();
	convertRotation2Translation();
	_actSpeedTran = (_actPositionTrans - _oldActPositionTrans)/_deltaT;
	//	printf("position %4.2f - %4.2f \n",_actualPosition,_desPosition);

	// PID
#if ROTATION
	double error = _desPosition - _actPosition;
	_integral += error * _deltaT;
	_desSpeed = _Kp * error + _Ki * _integral - _Kd * _actSpeed;
#else
	double error = _desPosition - _actPositionTrans;
	_integral += error * _deltaT;
	_desSpeed = _Kp * error + _Ki * _integral - _Kd * _actSpeedTran;
#endif
	//	_desSpeed = 3000;
	if (_desSpeed > MAX_SPEED)
		_desSpeed = MAX_SPEED;
	else if (_desSpeed < -MAX_SPEED)
		_desSpeed = -MAX_SPEED;
	// convert to DAC value

	//_desSpeed = 1000;
	convertSpeed2Volt();

	// Write to DAC
	//	printf("_setSpeed %5.5f - setPos %5.5f \n",_actPositionTrans,_desPosition);
	//printf("_setSpeedVolt %5.5f \n",_setSpeedVolt);

	if (COMEDI_ERROR == writeData(_subDevDAC,_setSpeedChanel,_rangeIDX,_aref,_setSpeedVolt)){
		//	printf("Error writing to subdev %d at channel %d value %2.2f \n",_subDevDAC,_setSpeedChanel,_setSpeedVolt);
	}
#else

	// Update actual position
	updateActualPositon();
	double prv_position = _actPositionTrans;
	convertRotation2Translation();
	_actSpeed = (_actPositionTrans - prv_position)/_deltaT;


	// Calculate set current

#if ROTATION
	double error;

	if (NORMAL == _state){
#if !CURRENT_CONTROL
		error = _desPosition - _actPosition;
		_integral += _err * _deltaT;
		_setCurent = _Kp * _err + _Ki * _integral + _Kd * (_err - _prv_error);  // PI Controller
//		printf("_desPosition %4.4f %4.4f  Error : %4.4f, Current: %2.4f\n",_desPosition,_actPosition,error,_setCurent);
#endif
	}
	else{
		_err = - _actPosition;
		_integral += _err * _deltaT;
		_setCurent = KP_DEFAULT * _err + KI_DEFAULT * _integral + KD_DEFAULT * (_err - _prv_error);  // PI Controller
	}
	_prv_error = _err;

#else

	double error;

	//updatePidParameters(error);
		if (NORMAL == _state){
#if !CURRENT_CONTROL
		_err = _desPosition - _actPositionTrans;
		_integral += _err * _deltaT;
		_setCurent = _Kp * _err + _Ki * _integral - _Kd * _actSpeed;  // PI Controller
#endif
	}
	else{
#if !DRILL
		error = - _actPositionTrans;
		_setCurent = KP_DEFAULT * error - KD_DEFAULT * _actSpeed;  // PI Controller
#else

		_err =  _static_position - _actPositionTrans;
		_setCurent = _Kp * _err  - _Kd * _actSpeed;  // PD
#endif
}
	_prv_error = error;

#endif
//	printf("_desPosition %4.4f %4.4f  Error : %4.4f, Current: %2.4f\n",_desPosition,_actPosition,error,_setCurent);

	if (_setCurent > MAX_CURRENT)
		_setCurent = MAX_CURRENT;
	else if (_setCurent < -MAX_CURRENT)
		_setCurent = -MAX_CURRENT;

//	printf("_desPosition %4.4f %4.4f  Error : %4.4f, Current: %2.4f\n",_desPosition,_actPosition,error,_setCurent);
	// Specify rotation direction
	//	if (err > 0)
	//		writeDIO(_subDevDIN,_directionChannel,MOTOR_CW);
	//	else
	//		writeDIO(_subDevDIN,_directionChannel,MOTOR_CCW);

	// convert to DAC & send to controller
	convertCurrent2Volt();
	//_setDACVolt = 0;
	if (COMEDI_ERROR == writeData(_subDevDAC,_setSpeedChanel,_rangeIDX,_aref,_setDACVolt)){
		//	printf("Error writing to subdev %d at channel %d value %2.2f \n",_subDevDAC,_setSpeedChanel,_setSpeedVolt);
	}

	//	_err = err;
#endif

}

Motor::~Motor() {
	// TODO Auto-generated destructor stub
}

int Motor::updateActualPositon() {
	/*
	// Read value from ADC
	if (COMEDI_ERROR == readData(_subDevADC,_actSpeedChannel,_rangeIDX,_aref)){
		return COMEDI_ERROR;
	} else {
		_actSpeedVolt = getVolAnalogInput(_actSpeedChannel);
	}
	// Convert voltage to Speed (RPM)
	convertVolt2Speed();

	// Integration of speed
	_actualPosition += _actSpeed * _posconvertfactor;

	return COMEDI_OK;
	 */
	if (COMEDI_OK == readCounter(COMEDI_COUNTER_SUB,COMEDI_COUNT_IN_0))
		_actPosition = getCounter(COMEDI_COUNT_IN_0);
//	printf("Counter: %d\n ",_actPosition);
}

void Motor::convertVolt2Speed() {
	// Voltage Range : -4 -> 4 V
	// Speed Range : -10000 -> 10000 RPM
	_actSpeed = 2500 * _actSpeedVolt ;
}

void Motor::setSamplingTime(double dT) {
	_deltaT = dT; // convert to minute for intergration
	_posconvertfactor = ENCODER_RESOLUTION*_deltaT/60;
}

void Motor::disable() {

	_setCurent = 0.0;
	// convert to DAC & send to controller
	convertCurrent2Volt();
	//_setDACVolt = 0;
	if (COMEDI_ERROR == writeData(_subDevDAC,_setSpeedChanel,_rangeIDX,_aref,_setDACVolt)){
		printf("Error writing to subdev %d at channel %d value %2.2f \n",_subDevDAC,_setSpeedChanel,_setSpeedVolt);
	}
	writeDIO(_subDevDIN,_enableChannel,false);

}

void Motor::convertSpeed2Volt() {
	// Voltage Range : -10 -> 10 V
	// Speed Range : -10000 -> 10000 RPM
	_setSpeedVolt = 0.001 * _desSpeed;
}

void Motor::convertCurrent2Volt(){
	_setDACVolt = 10 * _setCurent;
}

void Motor::setPosition(double pos) {
//	_desPosition = pos;

//	_desPosition = pos + _actPosition;
//
//	if (_desPosition < 0)
//		_desPosition = 0;
//	else if (_desPosition > MAX_POS){
//		_desPosition = MAX_POS;
//		//	printf("pos: %6.5f\n",_vm_position);
//	}
#if 0
	_desPosition = _err + _actPosition;
	if (_desPosition < 0)
		_err = -_actPosition;
	else if (_desPosition > MAX_POS){
		_err = MAX_POS - _actPosition;
		//	printf("pos: %6.5f\n",_vm_position);
	}

	_desPosition =  _err + _actPosition;
#else
	_desPosition = pos;

	// Saturation
	if (_desPosition < -MAX_POS)
		_desPosition = -MAX_POS;
	else if (_desPosition > MAX_POS)
		_desPosition = MAX_POS;

//	_err = _desPosition - _actPosition;
#endif
	//	printf("SET POS : %f\n",pos);
}


void Motor::setCurrent(double current){
	_setCurent = current;
}

void Motor::enable() {
	writeDIO(_subDevDIN,_enableChannel,true);
}

double Motor::getActualPosition() {
	return _actPosition;
}

double Motor::getActualTransPosition() {
	return _actPositionTrans;
}

double Motor::getDesignPositon() {

	return _desPosition;
}

void Motor::reset() {
	_static_position = 0.0;
	_state = RESET;
}

double Motor::getActualSpeed() {
	return _actSpeed;
}

void Motor::convertTranslation2Rotation() {
	// x = 5097 y
}

void Motor::loadScheduleGainParameters(string filename) {
	ifstream ifs(filename.c_str());
	string line;
	stringstream split;
	double val;
	if (ifs) {
		getline(ifs,line);
		while (!line.empty()){
			split.clear();
			split.str(line);
			split << line;

			split >> val;
			_SG_Kp.push_back(val);

			split >> val;
			_SG_Ki.push_back(val);

			split >> val;
			_SG_Kd.push_back(val);

			split >> val;
			_SG_range.push_back(val);

			getline(ifs,line);
		}
	}
	//	// Print

	// for (int j = 0; j < _SG_range.size();j++){
	// 	printf("Kp :%4.4f,Ki :%4.4f,Kd :%4.4f,range :%4.4f \n",_SG_Kp[j],_SG_Ki[j],_SG_Kd[j],_SG_range[j]);
	// }

}

void Motor::convertRotation2Translation() {
	// y = 0.0002 x
	if (abs(_actPosition) < EPSILON_ROTATION)
		_actPositionTrans = 0;
	else
		_actPositionTrans = A * _actPosition;

	if ((_actPositionTrans > _static_position) && (_state == NORMAL))
		_static_position = _actPositionTrans;
}

void Motor::rotateClockwise() {
	printf("rotating clockwise!");
	_desSpeed = LOW_SPEED;
	convertSpeed2Volt();
	// Write to DAC
	if (COMEDI_ERROR == writeData(_subDevDAC,_setSpeedChanel,_rangeIDX,_aref,_setSpeedVolt)){
		printf("Error writing to subdev %d at channel %d value %2.2f \n",_subDevDAC,_setSpeedChanel,_setSpeedVolt);
	}
}

void Motor::rotateCounterClockwise() {
	printf("rotating counterclockwise!");
	_desSpeed = -LOW_SPEED;
	convertSpeed2Volt();
	// Write to DAC
	if (COMEDI_ERROR == writeData(_subDevDAC,_setSpeedChanel,_rangeIDX,_aref,_setSpeedVolt)){
		printf("Error writing to subdev %d at channel %d value %2.2f \n",_subDevDAC,_setSpeedChanel,_setSpeedVolt);
	}
}

void Motor::stop() {
	printf("pause!");
	_desSpeed = 0;
	convertSpeed2Volt();
	// Write to DAC
	if (COMEDI_ERROR == writeData(_subDevDAC,_setSpeedChanel,_rangeIDX,_aref,_setSpeedVolt)){
		printf("Error writing to subdev %d at channel %d value %2.2f \n",_subDevDAC,_setSpeedChanel,_setSpeedVolt);
	}
}

void Motor::updatePidParameters(double val) {

	// find position
	int i;
	for (i = 0; i < _SG_range.size();i++){
		if (abs(val) <= _SG_range[i])
			break;
	}

	// Set PID
	if (i >= _SG_range.size())
		i = _SG_range.size() - 1;

	_Kp = _SG_Kp[i];
	_Ki = _SG_Ki[i];
	_Kd = _SG_Kd[i];

	printf("Kp :%4.4f,Ki :%4.4f,Kd :%4.4f \n",_Kp,_Ki,_Kd);
}

void Motor::getPidParameters(double& Kp, double& Ki, double& Kd) {
	Kp = _Kp;
	Ki = _Ki;
	Kd = _Kd;
}

void Motor::setState(MOTOR_STATE state) {
	if (RESET != _state)
		_state = state;

	if (_state == REALEASE)
		_static_position = _actPositionTrans;
}

void Motor::restartMotor(){
	_state = NORMAL;
}

double Motor::getDesignCurrent() {
	return _setCurent;
}

double Motor::getStaticPosition() {
	return _static_position;
}
