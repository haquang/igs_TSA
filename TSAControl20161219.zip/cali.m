%% Init
close all;
clear;
%% 
L = 42.5;
r = [2000;4000;6000;8000;10000;12000;15000;18000;20000;22000;25000;28000];
x = [42.41;42.30;41.76;41.47;41.13;40.54;40.08;38.92;38.00;37.38;35.85;34.23];

for i = 1: length(x)
    x(i) = L - x(i);
end

% curve fitting

P = polyfit(r,x,2)
K = x\r;
x_fit = P(1) * r.^2 + P(2) * r + P(3);

% Plot
figure();
scatter(r,x);
hold on;
plot(r,x_fit);