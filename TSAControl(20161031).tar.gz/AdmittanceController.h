/*
 * FSRSensor.h
 *
 *  Created on: Aug 17, 2016
 *      Author: haquang
 */

#ifndef ADMITTANCECONTROLLER_H_
#define ADMITTANCECONTROLLER_H_

#include "defines.h"
#include "daqdevice.h"

class AdmittanceController : public DaqDevice {

	double _extForce = 0.0f;	// External Force
	double _position = 0.0f;	// Position
	double _velocity = 0.0f;	// Velocity
	double _acceleration = 0.0f;// Acceleration
	double _deltaT = 0.0f;
	// Virtual Mass-Spring-Damper
	double _mass = 0.0f;
	double _spring = 0.0f;
	double _damper = 0.0f;

	// for Sensoray/NI card
	int _subDevADC;
	int _rangeIDX = 0;
	int _forceChannelRight;
	int _forceChannelLeft;
	int _aref = AREF_GROUND;
public:
	AdmittanceController();
	AdmittanceController(comedi_t* dev,int subDevADC,int forceChannelRight,int forceChannelLeft,int range);

	void solve();

	void setMassSpringDamperModel(double m,double k,double b);
	void setSamplingTime(double dT);
	double reset();
	double run();

	double getPosition();


	double getForce();


	virtual ~AdmittanceController();
private:
	void readForce();
};

#endif /* ADMITTANCECONTROLLER_H_ */
